package com.scaler.BookMyShow.models;

public enum Role {
    ADMIN,
    USER,
    THEATRE_OWNER
}
