package com.scaler.BookMyShow.models;

public enum Feature {
    IMAX,
    TWO_D,
    THREE_D,
    DOLBY_ATMOS,
    DOLBY_VISION
}
