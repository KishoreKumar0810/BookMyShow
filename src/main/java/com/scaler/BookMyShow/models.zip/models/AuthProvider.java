package com.scaler.BookMyShow.models;

public enum AuthProvider {
    LOCAL,
    GOOGLE,
    GITHUB
}
