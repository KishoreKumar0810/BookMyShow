package com.scaler.BookMyShow.models;

public enum ShowSeatStatus {
    SOLD,
    AVAILABLE,
    UNAVAILABLE,
    BLOCKED
}
