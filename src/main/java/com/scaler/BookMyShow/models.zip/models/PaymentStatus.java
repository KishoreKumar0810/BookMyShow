package com.scaler.BookMyShow.models;

public enum PaymentStatus {
    SUCCESS,
    FAILED,
    REFUNDED
}
