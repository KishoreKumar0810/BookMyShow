package com.scaler.BookMyShow.models;

public enum PaymentProvider {
     STRIPE,
    PHONEPE,
    RAZORPAY,
    PAYTM,
}
