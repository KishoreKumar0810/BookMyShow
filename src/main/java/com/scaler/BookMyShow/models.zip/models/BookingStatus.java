package com.scaler.BookMyShow.models;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    PENDING
}
