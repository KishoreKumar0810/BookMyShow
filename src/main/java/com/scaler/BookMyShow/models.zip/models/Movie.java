package com.scaler.BookMyShow.models;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
public class Movie extends BaseModel{
    private String title;
    private String genre;
    private int duration; // in minutes
    private Date releasedAt;
    private List<String> language;
}
